<div class="ResForm"></div>
<div class="ResbeforeSend"></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-footer">Contactanos</h4>
                <a href="#" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true">&nbsp; Facebook </i> 
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true">&nbsp; Twitter </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-youtube-play" aria-hidden="true">&nbsp; YouTube </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true">&nbsp; Instagram </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-map-marker" aria-hidden="true">&nbsp; Encuentranos </i>
                </a>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer">Porque elegirnos</h4>
                <p> 
                    Lorem ipsum dolor sit amet,adipisicing elit.</br>
                    Lorem ipsum dolor sit amet,adipisicing elit.</br>
                    Lorem ipsum dolor sit amet,adipisicing elit.</br>
                    Lorem ipsum dolor sit amet,adipisicing elit.</br>
                </p>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer" >Direccion</h4>
                <p style="color: #FFF">Tlaxcala tlax.</p>
                <p style="color: #FFF">Calle las casas # 15</p>
                <p style="font-size:20px" aria-hidden="true">  245 – 6584575 </p>
                <p class="fa fa-mobile" style="font-size:20px"  aria-hidden="true">  245 - 6584575 / 0000000</p> <a href="#" target="_blank" style="color: #5bc0de">envianos_un_mensaje</a></br>
                E-mail: <a href="#" target="_blank" style="color: #5bc0de"> &nbsp; floreriaautumn@dominio.com</a>
            </div>
        </div>
    </div>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo text-footer">STORE &copy; 2021</h5>
</footer>
